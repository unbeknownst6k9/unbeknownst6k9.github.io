package tableview;

import java.util.ArrayList;
import java.util.List;
//this is a helper class for searching
public class Search {
    public static List<PropertyAssessment> searchAccount(List<PropertyAssessment> masterList, int accountNumber){
        if(accountNumber == 0){
            return masterList;
        }
        List<PropertyAssessment> result = new ArrayList<>();
        for(PropertyAssessment i: masterList){
            if(i.getAccountNumber() == accountNumber){
                result.add(i);
            }
        }
        return result;
    }

    public static List<PropertyAssessment> searchAddress(List<PropertyAssessment> masterList, String address){
        if(address.equals("")){
            return masterList;
        }
        List<PropertyAssessment> result = new ArrayList<>();
        for(PropertyAssessment i: masterList){
            if((i.getAddress().toLowerCase()).contains(address.toLowerCase())){
                result.add(i);
            }
        }
        return result;
    }

    public static List<PropertyAssessment> searchClass(List<PropertyAssessment> masterList, String assessmentClass){
        if(assessmentClass.equals("")){
            return masterList;
        }
        List<PropertyAssessment> result = new ArrayList<>();
        for(PropertyAssessment i: masterList){
            if((i.getAssessClass().toLowerCase()).startsWith(assessmentClass.toLowerCase())){
                result.add(i);
            }
        }
        return result;
    }

    // CHANGED --> back to original
    public static List<PropertyAssessment> searchNeighborhood(List<PropertyAssessment> masterList, String neighborhood){
        if(neighborhood.equals("")){
            return masterList;
        }
        List<PropertyAssessment> result = new ArrayList<>();
        for (PropertyAssessment i : masterList) {
            if ((i.getNeighbourhood().toLowerCase()).startsWith(neighborhood.toLowerCase())) {
                result.add(i);
            }
        }
        return result;
    }

    // NEW --> similar search for NeighborhoodChart
    public static List<PropertyAssessment> searchNeighborhood2(List<PropertyAssessment> masterList, String neighborhood){
        List<PropertyAssessment> result = new ArrayList<>();
        if (neighborhood.equals("")){
            for (PropertyAssessment i : masterList) {
                if ((i.getNeighbourhood().toLowerCase().trim()).equals("")) {
                    result.add(i);
                }
            }
        }
        else{
            for (PropertyAssessment i : masterList) {
                if ((i.getNeighbourhood().toLowerCase()).startsWith(neighborhood.toLowerCase())) {
                    result.add(i);
                }
            }
        }
        return result;
    }

    public static List<PropertyAssessment> searchAssessmentRange(List<PropertyAssessment> masterList, int min, int max) {
        if (!rangeCheck(min, max)){
            throw new IllegalArgumentException("Minimum value is not between 0 and " + max);
        }
        List<PropertyAssessment> result = new ArrayList<>();
        for (PropertyAssessment pa: masterList){
            if(pa.getAssessValues() >= min && pa.getAssessValues() <= max){
                result.add(pa);
            }
        }
        return result;
    }

    //this is the method to filter out and give the final result
    public static List<PropertyAssessment> getResultList(List<PropertyAssessment> masterList,int accountNumber, String assessmentClass,
                                                  String neighborhood, String address){
        if(accountNumber == 0 && address.equals("") && neighborhood.equals("") && assessmentClass.equals("")){
            return masterList;//this is to save the computing power
        }
        List<PropertyAssessment> resultList  = searchClass(masterList, (assessmentClass.trim()).toLowerCase());
        resultList = searchNeighborhood(resultList, (neighborhood.trim()).toLowerCase());
        resultList = searchAddress(resultList, (address.trim()).toLowerCase());
        resultList = searchAccount(resultList, accountNumber);
        return resultList;
    }

    private static boolean rangeCheck(int value, int max){
        if (value < 0 || value > max){
            return false;
        }
        return true;
    }
}
