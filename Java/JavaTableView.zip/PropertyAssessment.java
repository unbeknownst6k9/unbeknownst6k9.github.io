package tableview;

//import sun.plugin.javascript.navig.Array;

import java.io.IOException;
import java.util.Arrays;


public class PropertyAssessment {
    private int accountNumber;
    private int assessValues;
    private String assessClass;
    private Address address;
    private Neighbourhood neighbour;
    private Location location;

    public PropertyAssessment(int accountNumber,
                              int assessValues,
                              String assessClass,
                              Address address,
                              Neighbourhood neighbourhood,
                              Location location) {
        this.accountNumber = accountNumber;
        this.assessValues = assessValues;
        this.assessClass = assessClass;
        this.address = address;
        this.neighbour = neighbourhood;
        this.location = location;
    }

    public Address getAddressInstance() {
        return address;
    }

    public Neighbourhood getNeighbourInstance() {
        return neighbour;
    }

    public Location getLocationInstance() {
        return location;
    }

    public String getAddress(){return (address.toString().equals("") ? "":address.toString());}

    public String getNeighbourhood(){return neighbour.getNeighbourhood();}

    public Double getLatitude(){return location.getLatitude();}

    public Double getLongitude(){return location.getLongitude();}

    public int getAccountNumber() {
        return accountNumber;
    }

    public int getAssessValues() {
        return assessValues;
    }

    public String getAssessClass() {
        return assessClass;
    }

    public String toString() {
        return ("Assessed Values = $" + assessValues + "\n" + "Assessment class = " + assessClass);
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof PropertyAssessment)) {
            return false;
        }
        PropertyAssessment pa = (PropertyAssessment) o;
        return this.assessValues == pa.assessValues && this.assessClass.equals(pa.assessClass) && this.accountNumber == pa.accountNumber &&
                this.address.equals(pa.getAddressInstance()) && this.neighbour.equals(pa.getNeighbourInstance()) &&
                this.location.equals(pa.getLocationInstance());
    }

    @Override
    public int hashCode() {
        int result = Integer.hashCode(assessValues);
        result = 31 * result + this.assessClass.hashCode();
        return result;
    }
}