package tableview;

// Adapted from:
// https://docs.oracle.com/javafx/2/ui_controls/table-view.htm
// https://docs.oracle.com/javase/8/javafx/api/javafx/scene/control/TableView.html
// Demonstrates how to format the values in a table view

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

public class TableViewFormat extends Application {

    private TableView<PropertyAssessment> table;
    private ObservableList<PropertyAssessment> assessmentTable;
    private PropertyAssessments assessments;

    private TextField accountNum;
    private TextField address;
    private ChoiceBox assessmentClasses;
    private TextField neighborhoods;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        //setup the container boxes
        primaryStage.setTitle("Edmonton Property Assessments");
        VBox searchBox = new VBox(10);
        searchBox.setPadding(new Insets(10,10,10,10));
        searchBox.setBorder(new Border(new BorderStroke(Color.GRAY, BorderStrokeStyle.SOLID, new CornerRadii(1), new BorderWidths(1))));
        HBox hBox = new HBox(10);
        VBox centerVBox = new VBox(10); // center VBox
        BorderPane backgroundPane = new BorderPane();
        CreateTabs sceneTabs = new CreateTabs();
        // set scene
        Scene scene = new Scene(sceneTabs.getAllPanels(), 900, 600);
        primaryStage.setScene(scene);


        final Label centerTitle = new Label("Edmonton Property Assessments");
        centerTitle.setFont(new Font("Arial", 16));
        //get the data
        configureTable();
        //setup the input of the search box and the title of each search boxes
        final Label searchTitle = new Label("Find Property Assessment");
        searchTitle.setFont(new Font("Arial",15.0));
        final Label accountText = new Label("Account Number:");
        accountNum = new TextField();
        final Label addressText = new Label("Address:");
        address = new TextField();
        final Label assessmentText = new Label("Assessment Class:");
        final Label neighborhoodText = new Label("Neighborhood:");
        neighborhoods = new TextField();
        TextArea assessValueSum = new TextArea();
        assessValueSum.setEditable(false);
        assessValueSum.prefWidthProperty().setValue(table.getPrefWidth() * 0.3);
        //
        assessments = new PropertyAssessments("Property_Assessment_Data__Current_Calendar_Year_.csv");
        List<PropertyAssessment> assessmentList = assessments.getAssessmentList();
        for (PropertyAssessment e: assessmentList){
            assessmentTable.add(e);
        }
        //declare and setup the choice box for the assessment class option
        ObservableList<String> options = FXCollections.observableArrayList((assessments.getAllAssessClass()));
        assessmentClasses = new ChoiceBox();
        assessmentClasses.getItems().add("");
        assessmentClasses.getItems().addAll(options);
        //create the search button
        Button searchBtn = new Button("Search");
        searchBtn.setOnAction(event -> {
            //this should return a list of result even if there is only one
            assessmentTable.clear();
            String selectedClass = (String)assessmentClasses.getValue();
            //get the result from calling the search
            List<PropertyAssessment> result = Search.getResultList(assessmentList, PropertyAssessments.parseEmptyString(accountNum.getText()),
                    (selectedClass == null? "":selectedClass)
                    , neighborhoods.getText(), address.getText());
            for (PropertyAssessment i: result) {
                assessmentTable.add(i);
            }
            if(result.size() > 1){//list out the assessment statistics if there's more than one data
                int[] reference = new int[result.size()];
                for (int i = 0; i<result.size(); i++){
                    reference[i] = result.get(i).getAssessValues();
                }
                assessValueSum.setText("Statistics of Assessed Values:\n\n"+PropertyAssessments.printAssessmentInfo(reference));
            }
            //clear all columns
            accountNum.clear();
            address.clear();
            neighborhoods.clear();
        });
        //
        Button redoBtn = new Button("Redo");
        redoBtn.setOnAction(actionEvent -> {
           assessmentTable.clear();
            for (PropertyAssessment e: assessmentList){
                assessmentTable.add(e);
            }
        });
        //add new tab into the scene
        TextField title = new TextField();
        Button addTab = new Button("Add Tab");
        addTab.setOnAction(actionEvent -> {
            sceneTabs.addPage(title.getText());
            title.clear();
        });

        //Text Area
        hBox.getChildren().addAll(searchBtn,redoBtn);
        searchBox.getChildren().addAll(searchTitle, accountText, accountNum, addressText, address,
                assessmentText, assessmentClasses, neighborhoodText, neighborhoods, hBox,
                new Separator(), assessValueSum, title, addTab);

        centerVBox.getChildren().addAll(centerTitle, table);
        centerVBox.setVgrow(table, Priority.ALWAYS);
        backgroundPane.setLeft(searchBox);
        backgroundPane.setCenter(centerVBox);
        backgroundPane.setMargin(centerVBox, new Insets(10,10,10,10));
        backgroundPane.setMargin(searchBox, new Insets(10, 10, 10, 10 ));

        sceneTabs.addTabs("Search",backgroundPane);
        sceneTabs.addSlidesShow("Slides", getChartList());
        //show the table
        primaryStage.show();
    }

    private List getChartList(){
        List<BarChart> chartList = new ArrayList<>();
        //create the assessment chart
        AssessmentChart assessChart = new AssessmentChart("Assessment Value Range", "Number of Assessments", assessments);
        assessChart.makeChart();
        chartList.add(assessChart.getBarChart());
        //create the assessment class chart
        AssessmentClassChart assessClassChart = new AssessmentClassChart("Assessment Class", "Number of Assessments", assessments);
        assessClassChart.makeChart();
        chartList.add(assessClassChart.getBarChart());
        //create the neighborhood charts
        NeighborhoodChartList neighborList = new NeighborhoodChartList(assessments);
        neighborList.makeChartList();
        List<BarChart> ref = neighborList.getChartList();
        for (BarChart e: ref) {
            chartList.add(e);
        }
        return chartList;
    }


    private void configureTable() {
        table = new TableView<>();//initialize table
        assessmentTable = FXCollections.observableArrayList();
        table.setItems(assessmentTable);//this will update whenever the list has changed

        //account number column
        TableColumn<PropertyAssessment, Integer> accountNum = new TableColumn<>("Account Number");
        accountNum.setCellValueFactory(new PropertyValueFactory<>("accountNumber"));
        accountNum.prefWidthProperty().bind(table.widthProperty().multiply(0.1));

        //address column
        TableColumn addressCol = createColumn("","Address","address");
        addressCol.prefWidthProperty().bind(table.widthProperty().multiply(0.2));

        //Assessed Value
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance();
        TableColumn<PropertyAssessment, Integer> assessValue = new TableColumn<>("Assessed Value");
        assessValue.setCellValueFactory(new PropertyValueFactory<>("assessValues"));
        assessValue.prefWidthProperty().bind(table.widthProperty().multiply(0.1));
        assessValue.setCellFactory(tc -> new TableCell<>() {
            @Override
            protected void updateItem(Integer value, boolean empty) {
                super.updateItem(value, empty);
                currencyFormat.setMaximumFractionDigits(0);//set the decimal place
                setText(empty ? "" : currencyFormat.format(value));
            }
        });

        //Assessment Class
        TableColumn assessClass = createColumn("","Assessment Class","assessClass");
        assessClass.prefWidthProperty().bind(table.widthProperty().multiply(0.1));
        //Neighbourhood
        TableColumn neighbour = createColumn("","Neighbourhood","neighbourhood");
        neighbour.prefWidthProperty().bind(table.widthProperty().multiply(0.25));
        //Location
        NumberFormat latitude = NumberFormat.getNumberInstance();
        TableColumn<PropertyAssessment, Double> latitudeCol = new TableColumn<>("Latitude");
        latitudeCol.setCellValueFactory(new PropertyValueFactory<>("latitude"));
        latitudeCol.setCellFactory(tc-> new TableCell<>(){
            @Override
            protected void updateItem(Double lat, boolean empty) {
                super.updateItem(lat, empty);
                setText(empty ? "" : latitude.format(lat));
            }
        });
        latitudeCol.prefWidthProperty().bind(table.widthProperty().multiply(0.125));

        NumberFormat longitude = NumberFormat.getNumberInstance();
        TableColumn<PropertyAssessment, Double> longitudeCol = new TableColumn<>("Longitude");
        longitudeCol.setCellValueFactory(new PropertyValueFactory<>("longitude"));
        longitudeCol.setCellFactory(tc-> new TableCell<>(){
            @Override
            protected void updateItem(Double lat, boolean empty) {
                super.updateItem(lat, empty);
                setText(empty ? "" : longitude.format(lat));
            }
        });
        longitudeCol.prefWidthProperty().bind(table.widthProperty().multiply(0.125));

        table.getColumns().setAll(accountNum, addressCol,assessValue, assessClass, neighbour, latitudeCol, longitudeCol);
    }

    //helper function for inner use only
    private TableColumn createColumn(Object object, String columnName, String getMethod){
            TableColumn<PropertyAssessment, String> column = new TableColumn<>(columnName);
            column.setCellValueFactory(new PropertyValueFactory<>(getMethod));
            return column;
    }
}