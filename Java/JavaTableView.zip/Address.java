package tableview;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Scanner;

public class Address {
    //#suite, #house, street name
    private String suitNum;
    private int houseNum;
    private String streetName;

    public Address(String suitNum, int houseNum, String streetName){
        this.suitNum = suitNum;
        this.houseNum = houseNum;
        this.streetName = streetName;
    }

    public String getSuit(){
        return this.suitNum;
    }

    public int getHouseNum(){
        return this.houseNum;
    }

    public String getStreetName(){
        return this.streetName;
    }

    public String toString(){
        return suitNum+" "+(houseNum == 0? "":houseNum)+" "+streetName;
    }

    public boolean equals(Object o){
        if(o == this){
            return true;
        }
        if(!(o instanceof Address)){
            return false;
        }
        Address ad = (Address) o;
        return ad.houseNum == houseNum && ad.suitNum == suitNum && ad.streetName.equals(streetName);
    }

    @Override
    public int hashCode(){
        int result = Integer.hashCode(houseNum);
        result = 31*result + suitNum.hashCode();
        result = 31*result + streetName.hashCode();
        return result;
    }
}
