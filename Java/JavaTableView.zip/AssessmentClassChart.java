package tableview;

import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import java.util.List;

public class AssessmentClassChart{
    private String xLabel;
    private String yLabel;
    List<PropertyAssessment> assessmentList;
    private BarChart barChart;


    // making chart with number of assessments in each assessment class, separated by range
    public AssessmentClassChart(String xLabel, String yLabel, PropertyAssessments assessments){
        this.xLabel = xLabel;
        this.yLabel = yLabel;
        assessmentList = assessments.getAssessmentList();
    }

    public void setXLabel(String xLabel){
        this.xLabel = xLabel;
    }

    public void setYLabel(String yLabel){
        this.yLabel = yLabel;
    }

    /**
     * function to make bar chart of this type.
     * Call after setting correct information
     */
    public void makeChart(){
        // initialize bar chart
        barChart = CommonFunctions.initializeChart(xLabel, yLabel);
        int max = CommonFunctions.getMax(assessmentList);
        int min = CommonFunctions.getMin(assessmentList);
        // Bar names
        XYChart.Series<String, Number> lowRange = new XYChart.Series<>();
        lowRange.setName("$0 - $200,000");
        XYChart.Series<String, Number> mediumRange = new XYChart.Series<>();
        mediumRange.setName("$200,000 - $500,000");
        XYChart.Series<String, Number> highRange = new XYChart.Series<>();
        highRange.setName("$500,000+");

        // Get each assessment class list
        List<PropertyAssessment> residentialList = Search.searchClass(assessmentList, "Residential");
        List<PropertyAssessment> nonResidentialList = Search.searchClass(assessmentList, "Non Residential");
        List<PropertyAssessment> otherResidentialList = Search.searchClass(assessmentList, "Other Residential");
        List<PropertyAssessment> farmlandList = Search.searchClass(assessmentList, "Farmland");
        // Add to 0 - 200,000 range
        CommonFunctions.addToAssessmentSeries(residentialList, "Residential", min, 200000, lowRange);
        CommonFunctions.addToAssessmentSeries(nonResidentialList, "Non Residential", min, 200000, lowRange);
        CommonFunctions.addToAssessmentSeries(otherResidentialList, "Other Residential", min, 200000, lowRange);
        CommonFunctions.addToAssessmentSeries(farmlandList, "Farmland", min, 200000, lowRange);

        // Add to 200,000 - 500,000 range
        CommonFunctions.addToAssessmentSeries(residentialList, "Residential", 200000, 500000, mediumRange);
        CommonFunctions.addToAssessmentSeries(nonResidentialList, "Non Residential", 200000, 500000, mediumRange);
        CommonFunctions.addToAssessmentSeries(otherResidentialList, "Other Residential", 200000, 500000, mediumRange);
        CommonFunctions.addToAssessmentSeries(farmlandList, "Farmland", 200000, 500000, mediumRange);

        // Add to 500,000+ range
        CommonFunctions.addToAssessmentSeries(residentialList, "Residential", 500000, max, highRange);
        CommonFunctions.addToAssessmentSeries(nonResidentialList, "Non Residential", 500000, max, highRange);
        CommonFunctions.addToAssessmentSeries(otherResidentialList, "Other Residential", 500000, max, highRange);
        CommonFunctions.addToAssessmentSeries(farmlandList, "Farmland", 500000, max, highRange);

        barChart.getData().addAll(lowRange, mediumRange, highRange);
    }

    public BarChart getBarChart() {
        return barChart;
    }
}
