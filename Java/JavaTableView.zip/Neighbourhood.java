package tableview;

public class Neighbourhood {
    //neighbourhood id, neighbourhood, ward, garage
    private int neighbourhoodID;
    private String neighbourhood;
    private int ward;
    private boolean garage;

    public Neighbourhood(int neighbourhoodID, String neighbourhood, String ward, boolean garage){
        this.neighbourhoodID = neighbourhoodID;
        this.neighbourhood = neighbourhood;
        this.ward = extractInt(ward);
        this.garage = garage;
    }
    //make all the data accessible
    public int getNeighbourhoodID(){
        return this.neighbourhoodID;
    }

    public String getNeighbourhood() {
        return this.neighbourhood;
    }

    public int getWard() {
        return this.ward;
    }

    public boolean getGarage() {
        return this.garage;
    }

    public static int extractInt(String string) {
        String newStr = string.replaceAll("\\s+","");
        newStr = newStr.replaceAll("[a-zA-z]","");
        if(newStr.equals("")){
            return 0;
        }
        return Integer.parseInt(newStr);
    }

    //print out the data
    public String toString(){
        return (neighbourhood+" ward ("+ward+")");
    }

    public boolean equals(Object o){
        if(o == this){
            return true;
        }
        if (!(o instanceof Neighbourhood)){
            return false;
        }
        Neighbourhood neighbour = (Neighbourhood) o;
        return neighbour.neighbourhoodID == neighbourhoodID && neighbour.neighbourhood.equals(neighbourhood) &&
                neighbour.ward == ward && neighbour.garage == garage;
    }

    @Override
    public int hashCode() {
        int result = Integer.hashCode(neighbourhoodID);
        result = 31*result + Integer.hashCode(ward);
        result = 31*result + Boolean.hashCode(garage);
        result = 31*result + neighbourhood.hashCode();
        return result;
    }
}
