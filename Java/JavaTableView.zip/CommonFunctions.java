package tableview;

import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

import java.util.List;

public class CommonFunctions{
        public static void addToAssessmentSeries(List<PropertyAssessment> pa, String category, int min, int max, XYChart.Series series){
            List<PropertyAssessment> tmpList = Search.searchAssessmentRange(pa, min, max);
            series.getData().add(new XYChart.Data<>(category, tmpList.size()));
        }

        public static int getMax(List<PropertyAssessment> assessmentList){
            int[] reference = new int[assessmentList.size()];
            for (int i = 0; i<assessmentList.size(); i++){
                reference[i] = assessmentList.get(i).getAssessValues();
            }
            return PropertyAssessments.getMax(reference);
        }

         public static int getMin(List<PropertyAssessment> assessmentList){
             int[] reference = new int[assessmentList.size()];
             for (int i = 0; i<assessmentList.size(); i++){
                 reference[i] = assessmentList.get(i).getAssessValues();
             }
             return PropertyAssessments.getMin(reference);
         }

         public static BarChart initializeChart(String xLabel, String yLabel){
             // x-axis
             CategoryAxis xAxis = new CategoryAxis();
             xAxis.setLabel(xLabel);

             // y-axis
             NumberAxis yAxis = new NumberAxis();
             yAxis.setLabel(yLabel);

             // make barChart
             BarChart barChart = new BarChart<>(xAxis, yAxis);
             barChart.setTitle(xLabel + " Vs. " + yLabel);
             return barChart;
         }
}
