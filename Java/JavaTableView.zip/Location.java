package tableview;

import java.util.Map;
import java.util.HashMap;


public class Location {
    //longitude, latitude
    private double longitude;
    private double latitude;

    public Location(double latitude, double longitude){
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public double getLatitude() {
        return this.latitude;
    }

    public double getLongitude() {
        return this.longitude;
    }

    public String toString(){
        return ("Location = ("+latitude+","+longitude+")");
    }

    public boolean equals(Object o){
        if(o == this){
            return true;
        }
        if (!( o instanceof Location )){
            return false;
        }
        Location l = (Location) o;
        return l.latitude == latitude && l.longitude == longitude;
    }

    @Override
    public int hashCode(){
        int result = Double.hashCode(latitude);
        result = 31 * result + Double.hashCode(longitude);
        return  result;
    }
}
