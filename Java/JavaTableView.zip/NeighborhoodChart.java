package tableview;

import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;

import java.util.List;

public class NeighborhoodChart {
    private String xLabel;
    private String yLabel;
    List<PropertyAssessment> assessmentList;
    List<String> uniqueNeighborhoods;
    private BarChart barChart;
    private int neighborhoodIndex; // starts at 1
    private int numberOfCategories;


    // making chart with number of assessments in each assessment class, separated by range
    public NeighborhoodChart(String xLabel, String yLabel, PropertyAssessments assessments, int neighborhoodIndex, int numberOfCategories) {
        this.xLabel = xLabel;
        this.yLabel = yLabel;
        this.neighborhoodIndex = neighborhoodIndex;
        this.numberOfCategories = numberOfCategories;
        uniqueNeighborhoods = assessments.getAllNeighborhoods();
        assessmentList = assessments.getAssessmentList();
    }

    public void setXLabel(String xLabel) {
        this.xLabel = xLabel;
    }

    public void setYLabel(String yLabel) {
        this.yLabel = yLabel;
    }

    public void makeChart() {
        // initialize bar chart
        barChart = CommonFunctions.initializeChart(xLabel, yLabel);
        int max = CommonFunctions.getMax(assessmentList);
        int min = CommonFunctions.getMin(assessmentList);
        // Bar names
        XYChart.Series<String, Number> lowRange = new XYChart.Series<>();
        lowRange.setName("$0 - $200,000");
        XYChart.Series<String, Number> mediumRange = new XYChart.Series<>();
        mediumRange.setName("$200,000 - $500,000");
        XYChart.Series<String, Number> highRange = new XYChart.Series<>();
        highRange.setName("$500,000+");

        if (neighborhoodIndex > uniqueNeighborhoods.size()){
            // end of list case
            for (int i = neighborhoodIndex - numberOfCategories; i < uniqueNeighborhoods.size(); i++){
                // start at index - # of categories, end at last neighborhoodIndex - 1
                // add numberOfCategories of neighborhoods into the graph
                String neighborhoodName = uniqueNeighborhoods.get(i);
                List<PropertyAssessment> neighborhoodAssessments = Search.searchNeighborhood2(assessmentList, neighborhoodName);
                CommonFunctions.addToAssessmentSeries(neighborhoodAssessments, neighborhoodName, min, 200000, lowRange);
                CommonFunctions.addToAssessmentSeries(neighborhoodAssessments, neighborhoodName, 200000, 500000, mediumRange);
                CommonFunctions.addToAssessmentSeries(neighborhoodAssessments, neighborhoodName, 500000, max, highRange);
            }
        }
        else{
            // normal case
            for (int i = neighborhoodIndex - numberOfCategories; i < neighborhoodIndex; i++){
                // start at index - # of categories, end neighborhoodIndex - 1
                // add numberOfCategories of neighborhoods into the graph
                String neighborhoodName = uniqueNeighborhoods.get(i);
                List<PropertyAssessment> neighborhoodAssessments = Search.searchNeighborhood2(assessmentList, neighborhoodName);
                CommonFunctions.addToAssessmentSeries(neighborhoodAssessments, neighborhoodName, min, 200000, lowRange);
                CommonFunctions.addToAssessmentSeries(neighborhoodAssessments, neighborhoodName, 200000, 500000, mediumRange);
                CommonFunctions.addToAssessmentSeries(neighborhoodAssessments, neighborhoodName, 500000, max, highRange);
            }
        }
        barChart.getData().addAll(lowRange, mediumRange, highRange);
    }
    public BarChart getBarChart() {
        return barChart;
    }
}
