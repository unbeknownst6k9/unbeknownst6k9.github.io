package tableview;

import javafx.scene.chart.BarChart;

import java.util.ArrayList;
import java.util.List;

public class NeighborhoodChartList {
    List<BarChart> chartList;
    PropertyAssessments assessments;
    NeighborhoodChart chart;

    public NeighborhoodChartList(PropertyAssessments assessments){
        this.assessments = assessments;
    }

    public void makeChartList(){
        // see NeighborhoodChart for details
        chartList = new ArrayList<>();
        for (int i = 5; i < assessments.getAllNeighborhoods().size(); i += 5) {
            chart = new NeighborhoodChart("Neighborhoods", "Number of Assessments",
                    assessments, i, 5);
            chart.makeChart();
            chartList.add(chart.getBarChart());
        }
    }

    public List getChartList(){
        return chartList;
    }
}
