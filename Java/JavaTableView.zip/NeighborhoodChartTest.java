package tableview;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.stage.Stage;


public class NeighborhoodChartTest extends Application {
    private BarChart barChart;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Assessment Class Value");
        NeighborhoodChart graph = new NeighborhoodChart("Neighborhoods", "Number of Assessments",
                new PropertyAssessments("Property_Assessment_Data__Current_Calendar_Year_.csv"),
                399, 5);
        // case 1 --> 5, 5 works
        // case 2 --> 400, 5 works = 4 charts (max neighborhoods = 399)
        graph.makeChart();
        Scene scene = new Scene(graph.getBarChart(), 900, 600);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

}

