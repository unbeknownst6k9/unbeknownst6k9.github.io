package tableview;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class TabContent {
    private ImageView image;
    private StackPane layer1;
    private BorderPane layout;

    public TabContent(){
        layer1 = new StackPane();
        layout = new BorderPane();
    }

    public void insertPicture(String title){
        layer1.setOnDragOver(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent dragEvent) {
                mouseDragOver(dragEvent);
            }
        });

        layer1.setOnDragDropped(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent dragEvent) {
                mouseDragDrop(dragEvent);
            }
        });

        layer1.setOnDragExited(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                layer1.setStyle("-fx-border-color: grey;");
            }
        });
        TextArea text = new TextArea();
        text.setWrapText(true);
        text.setText("Content goes here ...");
        TextArea titleText = setTitle(title);
        titleText.setMaxHeight(layout.getHeight()*0.3);
        layout.setTop(titleText);
        layout.setCenter(layer1);
        layout.setBottom(text);
    }

    public TextArea setTitle(String title){
        if(title.equals("")){title = "Title goes here ..."; }
        TextArea titleText = new TextArea(title);
        titleText.setStyle("-fx-font: 24 arial;");
        return titleText;
    }

    public void addImage(Image img, Pane pane){
        image = new ImageView();
        image.setImage(img);
        image.setFitWidth(pane.getWidth());
        image.setFitHeight(pane.getHeight());
        layer1.getChildren().add(image);
    }

    public void mouseDragDrop(final DragEvent event){
        final Dragboard db = event.getDragboard();
        boolean passed = false;
        if(db.hasFiles()){
            passed = true;
            final File file = db.getFiles().get(0);
            try{
            Image img = new Image(new FileInputStream(file.getAbsolutePath()));
            addImage(img, layer1);
            }catch (FileNotFoundException exception){
                System.out.println("File not found");
            }
        }
        event.setDropCompleted(passed);
        event.consume();
    }

    public  void mouseDragOver(final DragEvent event){
        final Dragboard db = event.getDragboard();
        final boolean isAccepted = db.getFiles().get(0).getName().toLowerCase().endsWith(".png")||
                db.getFiles().get(0).getName().toLowerCase().endsWith(".jpg")||
                db.getFiles().get(0).getName().toLowerCase().endsWith(".jpeg");

        if(db.hasFiles()){
            if(isAccepted){
                layer1.setStyle("-fx-border-color: #00008b;" +
                        "-fx-border-width: 5;" +
                        "-fx-background-color: #808080;" +
                        "-fx-border-style: solid;");
                event.acceptTransferModes(TransferMode.COPY);
            }else{
                event.consume();
            }
        }
    }

    public BorderPane getLayout() {
        return layout;
    }
}
