package tableview;

import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;

import java.util.List;

public class AssessmentChart {
    private String xLabel;
    private String yLabel;
    List<PropertyAssessment> assessmentList;
    private BarChart barChart;


    // making chart with number of assessments in each assessment class, separated by range
    public AssessmentChart(String xLabel, String yLabel, PropertyAssessments assessments){
        this.xLabel = xLabel;
        this.yLabel = yLabel;
        assessmentList = assessments.getAssessmentList();
    }

    public void setXLabel(String xLabel){
        this.xLabel = xLabel;
    }

    public void setYLabel(String yLabel){
        this.yLabel = yLabel;
    }

    public void makeChart(){
        // initialize chart
        barChart = CommonFunctions.initializeChart(xLabel, yLabel);
        int max = CommonFunctions.getMax(assessmentList);
        int min = CommonFunctions.getMin(assessmentList);
        // Bar names
        XYChart.Series<String, Number> lowRange = new XYChart.Series<>();
        lowRange.setName("$0 - $200,000");
        XYChart.Series<String, Number> mediumRange = new XYChart.Series<>();
        mediumRange.setName("$200,000 - $500,000");
        XYChart.Series<String, Number> highRange = new XYChart.Series<>();
        highRange.setName("$500,000+");
        // Add to 0 - 300,000 range
        CommonFunctions.addToAssessmentSeries(assessmentList, "", min, 200000, lowRange);
        // Add to 300,000 - 600,000 range
        CommonFunctions.addToAssessmentSeries(assessmentList, "", 200000, 500000, mediumRange);
        // Add to 600,000+ range
        CommonFunctions.addToAssessmentSeries(assessmentList, "", 500000, max, highRange);

        barChart.getData().addAll(lowRange, mediumRange, highRange);
    }

    public BarChart getBarChart() {
        return barChart;
    }
}
