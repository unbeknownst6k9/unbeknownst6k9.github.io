package tableview;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.text.NumberFormat;
import java.util.List;

public class CreateTabs {
    private TabPane allPanels;

    //initialize the tab pane
    public CreateTabs(){
        allPanels = new TabPane();
    }

    //add new tab into the tab pane
    //return none
    public void addTabs(String name, Node object){
        Tab newTab = new Tab(name, object);
        allPanels.getTabs().add(newTab);
    }

    //add the list of slides into a new tab
    //this will automatically add the slides into the tab
    //return none
    public void addSlidesShow(String title,List<Object> object){
        Pagination pagination = new Pagination();
        pagination.setPageCount(object.size());
        pagination.setCurrentPageIndex(0);
        pagination.setMaxPageIndicatorCount(6);

        pagination.setPageFactory((pageIndex) ->{
            VBox vBox = new VBox();
            vBox.getChildren().add((Node) object.get(pageIndex));
           return vBox;
        });
        addTabs(title,pagination);
    }

    public void addPage(String name){
        TabContent content = new TabContent();
        content.insertPicture(name);
        addTabs(name.equals("")? "Blank page":name, content.getLayout());
    }
    //return the result of the tab panel
    public TabPane getAllPanels() {
        return allPanels;
    }


}
