package tableview;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class AssessmentClassChartTest extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Assessment Class Value");
        AssessmentClassChart graph = new AssessmentClassChart("Assessment Class", "Number of Assessments", new PropertyAssessments("Property_Assessment_Data__Current_Calendar_Year_.csv"));
        graph.makeChart();
        Scene scene = new Scene(graph.getBarChart(), 900, 600);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
