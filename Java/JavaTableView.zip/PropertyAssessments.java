package tableview;

import java.io.IOException;
import java.nio.file.Paths;
import java.text.NumberFormat;
import java.util.*;
import java.util.Set;

public class PropertyAssessments {
    private String filename;
    private List<PropertyAssessment> assessmentList = new ArrayList<>();

//do the rest of the rolls just like property assessment by creating objects from
    //different class
    public PropertyAssessments(String filename) throws IOException{
        this.filename = filename;
        //read all assessed values
        Scanner file = new Scanner(Paths.get(filename));

        if(file.hasNextLine())
            file.nextLine();//skip header
        List<String> content;

        //put them into an array
        int counter = getNumberOfRecords(filename);
        int index = 0;
        while(file.hasNextLine() && index < counter){
            content = Arrays.asList(file.nextLine().split(","));
            //extract the ward number out
            int houseNum = parseEmptyString(content.get(2));
            Address address = new Address(content.get(1),houseNum,content.get(3));
            Location location = new Location(Double.parseDouble(content.get(10)), Double.parseDouble(content.get(11)));
            Neighbourhood neighbourhood = new Neighbourhood(parseEmptyString(content.get(6)),
                    content.get(7),content.get(8),
                    content.get(9).equals("Y"));

            assessmentList.add(new PropertyAssessment(Integer.parseInt(content.get(0)),
                    Integer.parseInt(content.get(4)),
                    content.get(5),
                    address,
                    neighbourhood,
                    location));
            index++;

        }
    }
/*
    public void printAccountInfo(int accountNumber){
            int index = -1;
            for (int i = 0; i < assessmentList.size(); i++) {
                if (assessmentList.get(i).getAccountNumber() == accountNumber) {
                    index = i;
                    break;//break out of the loop just so it doesn't have to loop through the whole thing
                }
            }
            //check if ID is found
            if (index == -1) {
                System.out.println("\nAccount Number " + accountNumber + " not found.\n");
            } else {
                //print out info
                System.out.println("Account Number = " + accountNumber);
                System.out.println("Address = " + assessmentList.get(index).getAddressInstance().toString());
                System.out.println(assessmentList.get(index).toString());
                System.out.println("Neighbourhood = " + assessmentList.get(index).getNeighbourInstance().getNeighbourhood() +
                        "(ward " + assessmentList.get(index).getNeighbourInstance().getWard() + ")");
                System.out.println(assessmentList.get(index).getLocationInstance().toString()+"\n");
            }
        }*/

    //helper function to handle empty input
    public static int parseEmptyString(String string){
        boolean haveAlpha = string.matches(".*[a-zA-z].*");//this prevent the number input which contains alphabet
        if(string.equals("") | haveAlpha){
            return 0;
        }else{
            return Integer.parseInt(string);
        }
    }

    //helper function to help print out the assessment info
    public static String printAssessmentInfo(int[] assessmentList){
        NumberFormat numFormat = NumberFormat.getInstance();
        NumberFormat curFormat = NumberFormat.getCurrencyInstance();
        curFormat.setMaximumFractionDigits(0);
        return ("the num is: " + numFormat.format(assessmentList.length)) + "\n" +
                ("the max is: " + curFormat.format(getMax(assessmentList))) + "\n" +
                ("the min is: " + curFormat.format(getMin(assessmentList))) + "\n" +
                ("the range is: " + curFormat.format(getMax(assessmentList) - getMin(assessmentList))) + "\n" +
                ("the mean is: " + curFormat.format(getMean(assessmentList))) + "\n" +
                ("the sd is: " + curFormat.format(getSD(assessmentList))) + "\n" +
                ("the median is: " + curFormat.format(getMedian(assessmentList)) + "\n");
    }

    public List getAssessmentList(){
        return assessmentList;
    }

    public List getAllAssessClass(){
        Set<String> assessClass = new HashSet<String>();
        for (PropertyAssessment i: assessmentList){
            assessClass.add(i.getAssessClass());
        }
        List<String> ref = new ArrayList<>();
        ref.addAll(assessClass);
        return ref;
    }


    public static int getMax(int[] Values){
        if (Values.length == 0){return -1;}//handle the empty array input
        //Get reference
        int maxNum = 0;//primitive type
        //find the max value
        for (int i : Values){
            if(i > maxNum){
                maxNum = i;
            }
        }
        return maxNum;
    }

    public static int getMin(int[] Values){
        if (Values.length == 0){return -1;}
        //Get reference
        int minNum;//primitive type
        //find the min value
        minNum = Values[0];
        for (int i : Values){
            if(i < minNum){
                minNum = i;
            }
        }
        return minNum;
    }

    public static int getMean(int[] Values){
        if (Values.length == 0){return -1;}
        int divider = 0;
        double mean = 0;
        while (divider < Values.length){
            mean += (double) Values[divider];
            divider++;
        }
        return (int) (mean/divider);
    }

    public static int getMedian(int[] Values){
        if (Values.length == 0){return -1;}
        Arrays.sort(Values);
        double median = 0;
        if(Values.length %2 == 0){
            median = ((double)Values[Values.length/2]+(double)Values[Values.length/2 -1])/2;

        }
        else{
            median = Values[Values.length/2];
        }
        return (int) median;
    }

    public static int getNumberOfRecords(String filename) throws IOException{
        Scanner file = new Scanner(Paths.get(filename));
        if(file.hasNextLine())
            file.nextLine(); //ignore the header
        int numberOfRecords = 0;
        while(file.hasNextLine()){
            file.nextLine();
            numberOfRecords++;
        }
        return numberOfRecords;
    }


    //sd variable
    public static int getSD(int[] Values){
        if (Values.length == 0){return -1;}
        int length = Values.length;
        double sum = 0;
        for (Integer i: Values){
            sum += i;//get the sum
        }
        double mean = sum/length;
        sum = 0;
        for (int i : Values){
            sum += Math.pow((i - mean),2);
        }
        sum = sum/length;
        sum = Math.sqrt(sum);
        return (int) Math.round(sum);
    }

    public List getAllNeighborhoods(){
        Set<String> neighborhoods = new HashSet<>();
        for (PropertyAssessment pa: assessmentList){
            neighborhoods.add(pa.getNeighbourhood());
        }
        List<String> ref = new ArrayList<>(neighborhoods);
        Collections.sort(ref); // sort neighborhoods in alphabetical order
        return ref;
    }
}